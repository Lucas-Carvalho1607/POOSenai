package site;

public class Site {
    protected String enderecoWeb;
    protected String razaoSocial;
    protected String cnpj;
    protected Produto produto;


}
